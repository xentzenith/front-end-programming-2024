import React, {Component } from "react";
class HelloWorld extends Component {
render(){
return (
<div className="helloContainer">
<h1>Hello World</h1>
</div>
)
}
}
export default HelloWorld;